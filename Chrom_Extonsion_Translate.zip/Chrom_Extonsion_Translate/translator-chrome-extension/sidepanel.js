// sidepanel.js

const API_URL = 'http://localhost:8081/translator-service/api/translator/translate';
const API_USERNAME = 'admin';
const API_PASSWORD = 'password123';

const inputText = document.getElementById('inputText');
const outputText = document.getElementById('outputText');
const translateBtn = document.getElementById('translateBtn');
const clearBtn = document.getElementById('clearBtn');
const copyBtn = document.getElementById('copyBtn');
const loading = document.getElementById('loading');
const error = document.getElementById('error');

// Vérifier IMMÉDIATEMENT s'il y a du texte à traduire
checkForTextToTranslate();

// Vérifier toutes les 100ms pendant 2 secondes (au cas où le storage n'est pas prêt)
let checkCount = 0;
const checkInterval = setInterval(() => {
  checkCount++;
  checkForTextToTranslate();
  if (checkCount >= 20) {
    clearInterval(checkInterval);
  }
}, 100);

function checkForTextToTranslate() {
  chrome.storage.local.get(['textToTranslate'], (result) => {
    if (result.textToTranslate) {
      console.log('Texte trouvé:', result.textToTranslate);
      inputText.value = result.textToTranslate;
      chrome.storage.local.remove('textToTranslate');
      // Traduire automatiquement après un court délai
      setTimeout(() => {
        performTranslation();
      }, 200);
      clearInterval(checkInterval); // Arrêter de vérifier
    }
  });
}

// Événements
translateBtn.addEventListener('click', performTranslation);
clearBtn.addEventListener('click', clearFields);
copyBtn.addEventListener('click', copyToClipboard);

// Traduction avec Ctrl+Enter
inputText.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && e.ctrlKey) {
    performTranslation();
  }
});

// Fonction de traduction
async function performTranslation() {
  const text = inputText.value.trim();

  if (!text) {
    showError('Veuillez entrer un texte à traduire');
    return;
  }

  // Reset UI
  outputText.value = '';
  copyBtn.style.display = 'none';
  error.style.display = 'none';
  loading.style.display = 'block';
  translateBtn.disabled = true;

  try {
    const requestBody = {
      text: text
    };

    console.log('Envoi de la requête:', requestBody);

    const response = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Basic ' + btoa(API_USERNAME + ':' + API_PASSWORD)
      },
      body: JSON.stringify(requestBody)
    });

    console.log('Statut de la réponse:', response.status);

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Erreur serveur:', errorText);
      throw new Error(`Erreur HTTP: ${response.status}`);
    }

    const data = await response.json();
    console.log('Réponse reçue:', data);

    loading.style.display = 'none';
    translateBtn.disabled = false;

    if (data.translatedText) {
      outputText.value = data.translatedText;
      copyBtn.style.display = 'block';
    } else if (data.error) {
      showError(data.error);
    } else {
      showError('Réponse invalide du serveur');
    }

  } catch (err) {
    loading.style.display = 'none';
    translateBtn.disabled = false;
    showError('Erreur: ' + err.message);
    console.error('Erreur complète:', err);
  }
}

// Effacer les champs
function clearFields() {
  inputText.value = '';
  outputText.value = '';
  copyBtn.style.display = 'none';
  error.style.display = 'none';
}

// Copier dans le presse-papier
async function copyToClipboard() {
  try {
    await navigator.clipboard.writeText(outputText.value);
    const originalText = copyBtn.textContent;
    copyBtn.textContent = '✅ Copié !';
    setTimeout(() => {
      copyBtn.textContent = originalText;
    }, 2000);
  } catch (err) {
    // Fallback pour les anciens navigateurs
    outputText.select();
    document.execCommand('copy');
    const originalText = copyBtn.textContent;
    copyBtn.textContent = '✅ Copié !';
    setTimeout(() => {
      copyBtn.textContent = originalText;
    }, 2000);
  }
}

// Afficher une erreur
function showError(message) {
  error.textContent = '❌ ' + message;
  error.style.display = 'block';
}