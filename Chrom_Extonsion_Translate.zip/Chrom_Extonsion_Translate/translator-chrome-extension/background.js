// background.js - Service Worker pour l'extension

// Créer un menu contextuel lors de l'installation
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'translateToDarija',
    title: 'Traduire en Darija',
    contexts: ['selection']
  });
});

// Gérer les clics sur le menu contextuel
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'translateToDarija') {
    const selectedText = info.selectionText;
    
    // Stocker le texte AVANT d'ouvrir le panneau
    chrome.storage.local.set({ textToTranslate: selectedText }, () => {
      // Ouvrir le side panel APRÈS avoir stocké le texte
      chrome.sidePanel.open({ windowId: tab.windowId });
    });
  }
});

// Gérer le clic sur l'icône de l'extension
chrome.action.onClicked.addListener((tab) => {
  
  chrome.storage.local.remove('textToTranslate', () => {
    chrome.sidePanel.open({ windowId: tab.windowId });
  });
});