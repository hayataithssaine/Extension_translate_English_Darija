package ma.translator.rest;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import ma.translator.service.GeminiService;
import ma.translator.security.Secured;

@Path("/translator")
public class TranslatorResource {

    private final GeminiService geminiService = new GeminiService();

    @POST
    @Path("/translate")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Secured
    public Response translate(TranslationRequest request) {
        try {
            if (request == null || request.getText() == null) {
                return Response.status(400).entity("{\"error\":\"JSON invalide\"}").build();
            }
            String result = geminiService.translateText(request.getText());
            return Response.ok("{\"translatedText\":\"" + result + "\"}").build();
        } catch (Exception e) {
            return Response.status(500).entity("{\"error\":\"" + e.getMessage() + "\"}").build();
        }
    }
}