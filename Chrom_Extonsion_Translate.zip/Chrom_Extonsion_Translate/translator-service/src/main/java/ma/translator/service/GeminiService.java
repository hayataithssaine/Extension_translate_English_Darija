package ma.translator.service;

import org.apache.hc.client5.http.classic.methods.HttpPost;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.CloseableHttpResponse;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.core5.http.io.entity.StringEntity;
import org.apache.hc.core5.http.io.entity.EntityUtils;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.nio.charset.StandardCharsets;

public class GeminiService {
    
    private final String API_KEY = "AIzaSyAPvKX2ULdpdx7Go29jK6No56ffsqEc_S0";
    private final String API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + API_KEY;
    
    public String translateText(String text) {
        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpPost request = new HttpPost(API_URL);
            request.setHeader("Content-Type", "application/json");
            
            // Échapper les caractères spéciaux
            String escapedText = text.replace("\\", "\\\\")
                                    .replace("\"", "\\\"")
                                    .replace("\n", "\\n")
                                    .replace("\r", "\\r")
                                    .replace("\t", "\\t");
            
            // Prompt modifié pour demander une traduction en darija marocain
            String prompt = "Translate the following text to Moroccan Darija (Moroccan Arabic dialect). "
                          + "Give ONLY the translation in Darija using Arabic script or Latin letters, "
                          + "without any explanations or alternatives. Text to translate: " + escapedText;
            
            String jsonInput = "{\"contents\":[{\"parts\":[{\"text\":\"" + prompt + "\"}]}]}";
            
            request.setEntity(new StringEntity(jsonInput, StandardCharsets.UTF_8));
            
            try (CloseableHttpResponse response = httpClient.execute(request)) {
                String responseBody = EntityUtils.toString(response.getEntity(), StandardCharsets.UTF_8);
                JsonObject jsonResponse = JsonParser.parseString(responseBody).getAsJsonObject();
                
                // Vérifier s'il y a une erreur
                if (jsonResponse.has("error")) {
                    JsonObject error = jsonResponse.getAsJsonObject("error");
                    return "Google API Error: " + error.get("message").getAsString();
                }
                
                // Extraire la traduction
                if (jsonResponse.has("candidates")) {
                    return jsonResponse.getAsJsonArray("candidates")
                            .get(0).getAsJsonObject()
                            .getAsJsonObject("content")
                            .getAsJsonArray("parts")
                            .get(0).getAsJsonObject()
                            .get("text").getAsString().trim();
                } else {
                    return "No translation found in response";
                }
            }
        } catch (Exception e) {
            return "Exception: " + e.getMessage();
        }
    }
}