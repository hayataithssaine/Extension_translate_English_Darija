package ma.translator.security;

import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerRequestFilter;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.Provider;
import java.io.IOException;
import java.util.Base64;

@Provider
@Secured
public class AuthenticationFilter implements ContainerRequestFilter {

    private static final String AUTHORIZATION_HEADER = "Authorization";
    private static final String AUTHENTICATION_SCHEME = "Basic";
    
    private static final String USERNAME = "admin";
    private static final String PASSWORD = "password123";

    @Override
    public void filter(ContainerRequestContext requestContext) throws IOException {
        
        String authorizationHeader = requestContext.getHeaderString(AUTHORIZATION_HEADER);

        if (authorizationHeader == null || !authorizationHeader.startsWith(AUTHENTICATION_SCHEME + " ")) {
            abortWithUnauthorized(requestContext);
            return;
        }

        String base64Credentials = authorizationHeader.substring(AUTHENTICATION_SCHEME.length()).trim();
        
        try {
            byte[] decodedBytes = Base64.getDecoder().decode(base64Credentials);
            String credentials = new String(decodedBytes);
            
            String[] values = credentials.split(":", 2);
            
            if (values.length != 2) {
                abortWithUnauthorized(requestContext);
                return;
            }
            
            String username = values[0];
            String password = values[1];
            
            if (!USERNAME.equals(username) || !PASSWORD.equals(password)) {
                abortWithUnauthorized(requestContext);
                return;
            }
            
        } catch (Exception e) {
            abortWithUnauthorized(requestContext);
        }
    }

    private void abortWithUnauthorized(ContainerRequestContext requestContext) {
        requestContext.abortWith(
            Response.status(Response.Status.UNAUTHORIZED)
                .header("WWW-Authenticate", AUTHENTICATION_SCHEME + " realm=\"Translator API\"")
                .entity("{\"error\":\"Authentication required\"}")
                .build()
        );
    }
}