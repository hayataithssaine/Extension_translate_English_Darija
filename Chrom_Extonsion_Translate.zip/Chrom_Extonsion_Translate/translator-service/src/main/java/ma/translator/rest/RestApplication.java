package ma.translator.rest;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

@ApplicationPath("/api")
public class RestApplication extends Application {
    // Pas besoin de redéfinir getClasses()
    // Jersey découvrira automatiquement les classes annotées avec @Provider et @Path
}